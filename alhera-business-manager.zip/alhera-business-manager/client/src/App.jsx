\
import React, { useEffect, useMemo, useState } from "react";
import { api } from "./api";
import {
  BarChart3, Boxes, Building2, ClipboardList, DatabaseBackup, Factory,
  Home, Landmark, Plus, RefreshCcw, Search, WalletCards
} from "lucide-react";

const today = () => new Date().toISOString().slice(0, 10);

const STATUS = [
  ["waiting", "অপেক্ষারত"],
  ["supplier_ordered", "সরবরাহকারী অর্ডার"],
  ["production", "প্রোডাকশন"],
  ["pickup", "উত্তোলন"],
  ["delivery", "ডেলিভারি"],
  ["completed", "সম্পন্ন"],
  ["cancelled", "বাতিল"]
];

const fmt = (n) =>
  new Intl.NumberFormat("bn-BD", { maximumFractionDigits: 2 }).format(Number(n || 0));

const initialParty = { name: "", phone: "", address: "", opening_balance_receivable: 0, opening_balance_payable: 0, note: "" };
const initialProduct = { name: "", layer: "", material_combo: "", supplier_id: "", unit: "kg", estimated_purchase_price: 0, estimated_sale_price: 0, note: "" };
const initialOrder = {
  customer_id: "", supplier_id: "", product_type_id: "", product_name: "",
  unit: "kg", estimated_qty: 0, actual_qty: 0, purchase_rate: 0, sale_rate: 0,
  transport_cost: 0, extra_cost: 0, status: "waiting", order_date: today(), expected_date: "", note: ""
};
const initialPayment = { party_type: "customer", party_id: "", order_id: "", direction: "in", amount: 0, method: "cash", payment_date: today(), note: "" };
const initialExpense = { type: "business_expense", amount: 0, method: "cash", expense_date: today(), note: "" };

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [data, setData] = useState({
    dashboard: {}, customers: [], suppliers: [], productTypes: [], orders: [], payments: [], expenses: []
  });
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState("");

  async function loadAll() {
    setLoading(true);
    try {
      const [dashboard, customers, suppliers, productTypes, orders, payments, expenses] = await Promise.all([
        api.get("/dashboard"),
        api.get("/customers"),
        api.get("/suppliers"),
        api.get("/product-types"),
        api.get("/orders"),
        api.get("/payments"),
        api.get("/expenses")
      ]);
      setData({ dashboard, customers, suppliers, productTypes, orders, payments, expenses });
    } catch (e) {
      showToast(e.message);
    } finally {
      setLoading(false);
    }
  }

  function showToast(msg) {
    setToast(msg);
    window.clearTimeout(window.__toastTimer);
    window.__toastTimer = window.setTimeout(() => setToast(""), 3500);
  }

  useEffect(() => { loadAll(); }, []);

  const nav = [
    ["dashboard", "ড্যাশবোর্ড", Home],
    ["orders", "অর্ডার", ClipboardList],
    ["customers", "ক্রেতা", Building2],
    ["suppliers", "সরবরাহকারী", Factory],
    ["products", "পণ্য ধরন/দাম", Boxes],
    ["payments", "পেমেন্ট", WalletCards],
    ["expenses", "খরচ/উত্তোলন", Landmark],
    ["reports", "রিপোর্ট/ব্যাকআপ", BarChart3]
  ];

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="logo">AH</div>
          <div>
            <h1>Al-Hera</h1>
            <p>Business Manager</p>
          </div>
        </div>

        <nav>
          {nav.map(([key, label, Icon]) => (
            <button key={key} onClick={() => setPage(key)} className={page === key ? "active" : ""}>
              <Icon size={18} /> {label}
            </button>
          ))}
        </nav>
      </aside>

      <main>
        <header className="topbar">
          <div>
            <h2>{nav.find(n => n[0] === page)?.[1]}</h2>
            <p>Linked order + accounting system</p>
          </div>
          <button className="ghost" onClick={loadAll} disabled={loading}>
            <RefreshCcw size={16} /> {loading ? "Loading..." : "Refresh"}
          </button>
        </header>

        {toast && <div className="toast">{toast}</div>}

        {page === "dashboard" && <Dashboard data={data} />}
        {page === "orders" && <Orders data={data} reload={loadAll} showToast={showToast} />}
        {page === "customers" && <Parties type="customer" data={data} reload={loadAll} showToast={showToast} />}
        {page === "suppliers" && <Parties type="supplier" data={data} reload={loadAll} showToast={showToast} />}
        {page === "products" && <Products data={data} reload={loadAll} showToast={showToast} />}
        {page === "payments" && <Payments data={data} reload={loadAll} showToast={showToast} />}
        {page === "expenses" && <Expenses data={data} reload={loadAll} showToast={showToast} />}
        {page === "reports" && <Reports data={data} reload={loadAll} showToast={showToast} />}
      </main>
    </div>
  );
}

function Dashboard({ data }) {
  const d = data.dashboard || {};
  const cards = [
    ["মোট বিক্রয়", d.sales],
    ["মোট ক্রয়", d.purchase],
    ["গ্রস লাভ", d.grossProfit],
    ["ব্যবসায়িক খরচ", d.businessExpenses],
    ["নেট লাভ", d.netProfit],
    ["খরচ/উত্তোলন", d.ownerWithdrawals],
    ["ক্রেতার কাছে পাবো", d.receivable],
    ["সরবরাহকারী পাবে", d.payable]
  ];

  return (
    <section>
      <div className="grid cards">
        {cards.map(([label, value]) => (
          <div className="card" key={label}>
            <p>{label}</p>
            <h3>৳ {fmt(value)}</h3>
          </div>
        ))}
      </div>

      <div className="panel">
        <h3>আজকের কাজের নিয়ম</h3>
        <div className="steps">
          <span>১. ক্রেতার অর্ডার যোগ করুন</span>
          <span>২. একই অর্ডারে সরবরাহকারী নির্বাচন করুন</span>
          <span>৩. মাল বের হলে Actual Qty দিন</span>
          <span>৪. পেমেন্ট এন্ট্রি করুন</span>
          <span>৫. রিপোর্ট দেখুন</span>
        </div>
      </div>
    </section>
  );
}

function Parties({ type, data, reload, showToast }) {
  const isCustomer = type === "customer";
  const list = isCustomer ? data.customers : data.suppliers;
  const [form, setForm] = useState(initialParty);
  const [editingId, setEditingId] = useState("");
  const [q, setQ] = useState("");

  const filtered = list.filter(x => (x.name + " " + (x.phone || "")).toLowerCase().includes(q.toLowerCase()));

  async function submit(e) {
    e.preventDefault();
    try {
      const body = isCustomer
        ? { ...form, opening_balance_receivable: Number(form.opening_balance_receivable || 0) }
        : { ...form, opening_balance_payable: Number(form.opening_balance_payable || 0) };
      if (editingId) await api.put(`/${isCustomer ? "customers" : "suppliers"}/${editingId}`, body);
      else await api.post(`/${isCustomer ? "customers" : "suppliers"}`, body);
      setForm(initialParty);
      setEditingId("");
      showToast("সেভ হয়েছে");
      reload();
    } catch (e) { showToast(e.message); }
  }

  function edit(item) {
    setEditingId(item.id);
    setForm({
      name: item.name || "",
      phone: item.phone || "",
      address: item.address || "",
      opening_balance_receivable: item.opening_balance_receivable || 0,
      opening_balance_payable: item.opening_balance_payable || 0,
      note: item.note || ""
    });
  }

  return (
    <section className="split">
      <form className="panel form" onSubmit={submit}>
        <h3>{editingId ? "আপডেট করুন" : isCustomer ? "নতুন ক্রেতা যোগ করুন" : "নতুন সরবরাহকারী যোগ করুন"}</h3>
        <Input label="নাম" value={form.name} onChange={v => setForm({ ...form, name: v })} required />
        <Input label="মোবাইল" value={form.phone} onChange={v => setForm({ ...form, phone: v })} />
        <Input label="ঠিকানা" value={form.address} onChange={v => setForm({ ...form, address: v })} />
        {isCustomer ? (
          <Input type="number" label="পুরোনো পাওনা" value={form.opening_balance_receivable} onChange={v => setForm({ ...form, opening_balance_receivable: v })} />
        ) : (
          <Input type="number" label="পুরোনো দেনা" value={form.opening_balance_payable} onChange={v => setForm({ ...form, opening_balance_payable: v })} />
        )}
        <Textarea label="নোট" value={form.note} onChange={v => setForm({ ...form, note: v })} />
        <button className="primary"><Plus size={16} /> {editingId ? "আপডেট" : "সেভ"}</button>
      </form>

      <div className="panel">
        <SearchBox value={q} onChange={setQ} />
        <Table
          headers={["নাম", "মোবাইল", isCustomer ? "পুরোনো পাওনা" : "পুরোনো দেনা", "Action"]}
          rows={filtered.map(x => [
            x.name, x.phone || "-",
            `৳ ${fmt(isCustomer ? x.opening_balance_receivable : x.opening_balance_payable)}`,
            <button className="small" onClick={() => edit(x)}>Edit</button>
          ])}
        />
      </div>
    </section>
  );
}

function Products({ data, reload, showToast }) {
  const [form, setForm] = useState(initialProduct);
  const [editingId, setEditingId] = useState("");

  async function submit(e) {
    e.preventDefault();
    try {
      if (editingId) await api.put(`/product-types/${editingId}`, form);
      else await api.post("/product-types", form);
      setForm(initialProduct);
      setEditingId("");
      showToast("পণ্য ধরন/দাম সেভ হয়েছে");
      reload();
    } catch (e) { showToast(e.message); }
  }

  function edit(x) {
    setEditingId(x.id);
    setForm({
      name: x.name || "",
      layer: x.layer || "",
      material_combo: x.material_combo || "",
      supplier_id: x.supplier_id || "",
      unit: x.unit || "kg",
      estimated_purchase_price: x.estimated_purchase_price || 0,
      estimated_sale_price: x.estimated_sale_price || 0,
      note: x.note || ""
    });
  }

  return (
    <section className="split">
      <form className="panel form" onSubmit={submit}>
        <h3>{editingId ? "দাম/ধরন আপডেট" : "পণ্য ধরন যোগ করুন"}</h3>
        <Input label="পণ্যের ধরন" value={form.name} onChange={v => setForm({ ...form, name: v })} placeholder="যেমন: 2 Layer PET + LDPE" required />
        <Input label="লেয়ার" value={form.layer} onChange={v => setForm({ ...form, layer: v })} placeholder="1 Layer / 2 Layer / Cylinder" />
        <Input label="Material Combo" value={form.material_combo} onChange={v => setForm({ ...form, material_combo: v })} />
        <Select label="ডিফল্ট সরবরাহকারী" value={form.supplier_id} onChange={v => setForm({ ...form, supplier_id: v })}>
          <option value="">নির্বাচন করুন</option>
          {data.suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </Select>
        <Select label="Unit" value={form.unit} onChange={v => setForm({ ...form, unit: v })}>
          <option value="kg">kg</option>
          <option value="pcs">pcs</option>
          <option value="roll">roll</option>
        </Select>
        <Input type="number" label="আনুমানিক ক্রয় দর" value={form.estimated_purchase_price} onChange={v => setForm({ ...form, estimated_purchase_price: v })} />
        <Input type="number" label="আনুমানিক বিক্রয় দর" value={form.estimated_sale_price} onChange={v => setForm({ ...form, estimated_sale_price: v })} />
        <Textarea label="নোট" value={form.note} onChange={v => setForm({ ...form, note: v })} />
        <button className="primary"><Plus size={16} /> {editingId ? "আপডেট" : "সেভ"}</button>
      </form>

      <div className="panel">
        <Table
          headers={["ধরন", "Supplier", "ক্রয়", "বিক্রয়", "Action"]}
          rows={data.productTypes.map(x => [
            <div><b>{x.name}</b><small>{x.material_combo}</small></div>,
            x.supplier_name || "-",
            `৳ ${fmt(x.estimated_purchase_price)}/${x.unit}`,
            `৳ ${fmt(x.estimated_sale_price)}/${x.unit}`,
            <button className="small" onClick={() => edit(x)}>Edit</button>
          ])}
        />
      </div>
    </section>
  );
}

function Orders({ data, reload, showToast }) {
  const [form, setForm] = useState(initialOrder);
  const [editingId, setEditingId] = useState("");
  const [q, setQ] = useState("");

  const filtered = data.orders.filter(o =>
    (o.order_no + " " + o.product_name + " " + o.customer_name + " " + (o.supplier_name || "")).toLowerCase().includes(q.toLowerCase())
  );

  function applyProductType(id) {
    const pt = data.productTypes.find(x => x.id === id);
    if (!pt) return setForm({ ...form, product_type_id: id });
    setForm({
      ...form,
      product_type_id: id,
      product_type_name: pt.name,
      supplier_id: pt.supplier_id || form.supplier_id,
      unit: pt.unit || "kg",
      purchase_rate: pt.estimated_purchase_price || 0,
      sale_rate: pt.estimated_sale_price || 0
    });
  }

  async function submit(e) {
    e.preventDefault();
    try {
      if (editingId) await api.put(`/orders/${editingId}`, form);
      else await api.post("/orders", form);
      setForm(initialOrder);
      setEditingId("");
      showToast("অর্ডার সেভ হয়েছে");
      reload();
    } catch (e) { showToast(e.message); }
  }

  function edit(o) {
    setEditingId(o.id);
    setForm({
      customer_id: o.customer_id || "",
      supplier_id: o.supplier_id || "",
      product_type_id: o.product_type_id || "",
      product_type_name: o.product_type_name || "",
      product_name: o.product_name || "",
      unit: o.unit || "kg",
      estimated_qty: o.estimated_qty || 0,
      actual_qty: o.actual_qty || 0,
      purchase_rate: o.purchase_rate || 0,
      sale_rate: o.sale_rate || 0,
      transport_cost: o.transport_cost || 0,
      extra_cost: o.extra_cost || 0,
      status: o.status || "waiting",
      order_date: o.order_date || today(),
      expected_date: o.expected_date || "",
      note: o.note || ""
    });
  }

  async function quickStatus(id, status) {
    try {
      await api.patch(`/orders/${id}/status`, { status });
      showToast("স্ট্যাটাস আপডেট হয়েছে");
      reload();
    } catch (e) { showToast(e.message); }
  }

  const totalsPreview = useMemo(() => {
    const qty = Number(form.actual_qty || form.estimated_qty || 0);
    const sale = qty * Number(form.sale_rate || 0);
    const purchase = qty * Number(form.purchase_rate || 0);
    const profit = sale - purchase - Number(form.transport_cost || 0) - Number(form.extra_cost || 0);
    return { sale, purchase, profit };
  }, [form]);

  return (
    <section>
      <form className="panel form wide" onSubmit={submit}>
        <h3>{editingId ? "অর্ডার আপডেট করুন" : "নতুন বিক্রয় অর্ডার + সরবরাহকারী অর্ডার"}</h3>
        <div className="formgrid">
          <Select label="ক্রেতা" value={form.customer_id} onChange={v => setForm({ ...form, customer_id: v })} required>
            <option value="">ক্রেতা নির্বাচন</option>
            {data.customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          <Input label="পণ্যের নাম" value={form.product_name} onChange={v => setForm({ ...form, product_name: v })} placeholder="যেমন: ফুলকলি ব্রেড পলি" required />
          <Select label="পণ্যের ধরন" value={form.product_type_id} onChange={applyProductType}>
            <option value="">ধরন নির্বাচন</option>
            {data.productTypes.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
          <Select label="সরবরাহকারী/ফ্যাক্টরি" value={form.supplier_id} onChange={v => setForm({ ...form, supplier_id: v })}>
            <option value="">সরবরাহকারী নির্বাচন</option>
            {data.suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
          <Input type="number" label="Estimated Qty" value={form.estimated_qty} onChange={v => setForm({ ...form, estimated_qty: v })} />
          <Input type="number" label="Actual Qty" value={form.actual_qty} onChange={v => setForm({ ...form, actual_qty: v })} placeholder="মাল বের হলে দিন" />
          <Input type="number" label="ক্রয় দর" value={form.purchase_rate} onChange={v => setForm({ ...form, purchase_rate: v })} />
          <Input type="number" label="বিক্রয় দর" value={form.sale_rate} onChange={v => setForm({ ...form, sale_rate: v })} />
          <Input type="number" label="পরিবহন খরচ" value={form.transport_cost} onChange={v => setForm({ ...form, transport_cost: v })} />
          <Input type="number" label="অতিরিক্ত খরচ" value={form.extra_cost} onChange={v => setForm({ ...form, extra_cost: v })} />
          <Select label="স্ট্যাটাস" value={form.status} onChange={v => setForm({ ...form, status: v })}>
            {STATUS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
          <Input type="date" label="অর্ডার তারিখ" value={form.order_date} onChange={v => setForm({ ...form, order_date: v })} />
        </div>
        <Textarea label="নোট" value={form.note} onChange={v => setForm({ ...form, note: v })} />
        <div className="preview">
          <span>ক্রেতার বিল: ৳ {fmt(totalsPreview.sale)}</span>
          <span>সরবরাহকারীর বিল: ৳ {fmt(totalsPreview.purchase)}</span>
          <span>লাভ: ৳ {fmt(totalsPreview.profit)}</span>
        </div>
        <button className="primary"><Plus size={16} /> {editingId ? "আপডেট" : "অর্ডার সেভ"}</button>
      </form>

      <div className="panel">
        <SearchBox value={q} onChange={setQ} />
        <Table
          headers={["অর্ডার", "ক্রেতা", "সরবরাহকারী", "Qty", "বিল/লাভ", "স্ট্যাটাস", "Action"]}
          rows={filtered.map(o => [
            <div><b>{o.order_no}</b><small>{o.product_name}</small></div>,
            o.customer_name,
            o.supplier_name || "-",
            `${fmt(o.totals.qty)} ${o.unit}`,
            <div><b>Sale ৳{fmt(o.totals.sale)}</b><small>Buy ৳{fmt(o.totals.purchase)} | Profit ৳{fmt(o.totals.grossProfit)}</small></div>,
            <StatusBadge status={o.status} />,
            <div className="actions">
              <button className="small" onClick={() => edit(o)}>Edit</button>
              <select className="smallselect" value={o.status} onChange={(e) => quickStatus(o.id, e.target.value)}>
                {STATUS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </div>
          ])}
        />
      </div>
    </section>
  );
}

function Payments({ data, reload, showToast }) {
  const [form, setForm] = useState(initialPayment);

  const partyList = form.party_type === "customer" ? data.customers : data.suppliers;
  const orderList = data.orders.filter(o =>
    form.party_type === "customer" ? o.customer_id === form.party_id : o.supplier_id === form.party_id
  );

  function updatePartyType(party_type) {
    setForm({ ...form, party_type, party_id: "", order_id: "", direction: party_type === "customer" ? "in" : "out" });
  }

  async function submit(e) {
    e.preventDefault();
    try {
      await api.post("/payments", form);
      setForm(initialPayment);
      showToast("পেমেন্ট সেভ হয়েছে");
      reload();
    } catch (e) { showToast(e.message); }
  }

  return (
    <section className="split">
      <form className="panel form" onSubmit={submit}>
        <h3>পেমেন্ট যোগ করুন</h3>
        <Select label="ধরন" value={form.party_type} onChange={updatePartyType}>
          <option value="customer">ক্রেতার কাছ থেকে টাকা পেলাম</option>
          <option value="supplier">সরবরাহকারীকে টাকা দিলাম</option>
        </Select>
        <Select label="পার্টি" value={form.party_id} onChange={v => setForm({ ...form, party_id: v, order_id: "" })} required>
          <option value="">নির্বাচন করুন</option>
          {partyList.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </Select>
        <Select label="অর্ডার" value={form.order_id} onChange={v => setForm({ ...form, order_id: v })}>
          <option value="">সব/পুরোনো হিসাব</option>
          {orderList.map(o => <option key={o.id} value={o.id}>{o.order_no} - {o.product_name}</option>)}
        </Select>
        <Input type="number" label="Amount" value={form.amount} onChange={v => setForm({ ...form, amount: v })} required />
        <Select label="Method" value={form.method} onChange={v => setForm({ ...form, method: v })}>
          <option value="cash">Cash</option>
          <option value="bkash">bKash</option>
          <option value="bank">Bank</option>
          <option value="cheque">Cheque</option>
        </Select>
        <Input type="date" label="তারিখ" value={form.payment_date} onChange={v => setForm({ ...form, payment_date: v })} />
        <Textarea label="নোট" value={form.note} onChange={v => setForm({ ...form, note: v })} />
        <button className="primary">সেভ</button>
      </form>

      <div className="panel">
        <Table
          headers={["তারিখ", "পার্টি", "ধরন", "Amount", "Method"]}
          rows={data.payments.map(p => [
            p.payment_date,
            p.party_name || "-",
            p.party_type === "customer" ? "Received" : "Paid",
            `৳ ${fmt(p.amount)}`,
            p.method
          ])}
        />
      </div>
    </section>
  );
}

function Expenses({ data, reload, showToast }) {
  const [form, setForm] = useState(initialExpense);

  async function submit(e) {
    e.preventDefault();
    try {
      await api.post("/expenses", form);
      setForm(initialExpense);
      showToast("খরচ/উত্তোলন সেভ হয়েছে");
      reload();
    } catch (e) { showToast(e.message); }
  }

  return (
    <section className="split">
      <form className="panel form" onSubmit={submit}>
        <h3>খরচ ও উত্তোলন যোগ করুন</h3>
        <Select label="ধরন" value={form.type} onChange={v => setForm({ ...form, type: v })}>
          <option value="business_expense">ব্যবসায়িক খরচ</option>
          <option value="owner_withdrawal">খরচ/উত্তোলন</option>
        </Select>
        <Input type="number" label="Amount" value={form.amount} onChange={v => setForm({ ...form, amount: v })} required />
        <Select label="Method" value={form.method} onChange={v => setForm({ ...form, method: v })}>
          <option value="cash">Cash</option>
          <option value="bkash">bKash</option>
          <option value="bank">Bank</option>
        </Select>
        <Input type="date" label="তারিখ" value={form.expense_date} onChange={v => setForm({ ...form, expense_date: v })} />
        <Textarea label="কারণে/বিস্তারিত" value={form.note} onChange={v => setForm({ ...form, note: v })} />
        <button className="primary">সেভ</button>
      </form>

      <div className="panel">
        <Table
          headers={["তারিখ", "ধরন", "Amount", "Method", "নোট"]}
          rows={data.expenses.map(e => [
            e.expense_date,
            e.type === "owner_withdrawal" ? "খরচ/উত্তোলন" : "ব্যবসায়িক খরচ",
            `৳ ${fmt(e.amount)}`,
            e.method,
            e.note || "-"
          ])}
        />
      </div>
    </section>
  );
}

function Reports({ data, reload, showToast }) {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [monthly, setMonthly] = useState(null);
  const [backups, setBackups] = useState([]);

  async function loadMonthly() {
    try {
      setMonthly(await api.get(`/reports/monthly?month=${month}`));
    } catch (e) { showToast(e.message); }
  }

  async function backup() {
    try {
      await api.post("/backup", {});
      setBackups(await api.get("/backups"));
      showToast("Backup তৈরি হয়েছে");
    } catch (e) { showToast(e.message); }
  }

  useEffect(() => { loadMonthly(); api.get("/backups").then(setBackups).catch(() => {}); }, []);

  return (
    <section>
      <div className="panel">
        <h3>মাসিক রিপোর্ট</h3>
        <div className="inline">
          <input type="month" value={month} onChange={e => setMonth(e.target.value)} />
          <button className="primary" onClick={loadMonthly}>রিপোর্ট দেখুন</button>
        </div>
        {monthly && (
          <div className="grid cards">
            <div className="card"><p>বিক্রয়</p><h3>৳ {fmt(monthly.sales)}</h3></div>
            <div className="card"><p>ক্রয়</p><h3>৳ {fmt(monthly.purchase)}</h3></div>
            <div className="card"><p>গ্রস লাভ</p><h3>৳ {fmt(monthly.grossProfit)}</h3></div>
            <div className="card"><p>নেট লাভ</p><h3>৳ {fmt(monthly.netProfit)}</h3></div>
            <div className="card"><p>খরচ/উত্তোলন</p><h3>৳ {fmt(monthly.ownerWithdrawals)}</h3></div>
            <div className="card"><p>অর্ডার</p><h3>{fmt(monthly.orders)}</h3></div>
          </div>
        )}
      </div>

      <div className="panel">
        <h3>CSV Export</h3>
        <div className="export-grid">
          {["customers", "suppliers", "product_types", "orders", "payments", "expenses"].map(name => (
            <a className="download" key={name} href={api.url(`/export/${name}.csv`)} target="_blank">
              {name}.csv
            </a>
          ))}
        </div>
      </div>

      <div className="panel">
        <h3>Backup</h3>
        <button className="primary" onClick={backup}><DatabaseBackup size={16} /> Backup Now</button>
        <div className="backup-list">
          {backups.slice(0, 10).map(b => <span key={b}>{b}</span>)}
        </div>
      </div>
    </section>
  );
}

function Input({ label, value, onChange, type = "text", required = false, placeholder = "" }) {
  return (
    <label>
      <span>{label}</span>
      <input
        type={type}
        value={value ?? ""}
        placeholder={placeholder}
        required={required}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function Textarea({ label, value, onChange }) {
  return (
    <label>
      <span>{label}</span>
      <textarea value={value ?? ""} onChange={(e) => onChange(e.target.value)} rows={3} />
    </label>
  );
}

function Select({ label, value, onChange, required, children }) {
  return (
    <label>
      <span>{label}</span>
      <select value={value ?? ""} required={required} onChange={(e) => onChange(e.target.value)}>
        {children}
      </select>
    </label>
  );
}

function SearchBox({ value, onChange }) {
  return (
    <div className="search">
      <Search size={16} />
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder="Search..." />
    </div>
  );
}

function Table({ headers, rows }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>{headers.map(h => <th key={h}>{h}</th>)}</tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td colSpan={headers.length} className="empty">No data</td></tr>
          ) : rows.map((r, i) => (
            <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StatusBadge({ status }) {
  const label = STATUS.find(s => s[0] === status)?.[1] || status;
  return <span className={`badge ${status}`}>{label}</span>;
}
