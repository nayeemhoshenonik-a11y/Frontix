# Al-Hera Business Manager

Packaging factory/order/accounting management system for:
- Customers
- Suppliers / factories
- Product type and price setup
- Linked customer order + supplier order
- Actual weight correction
- Receivable / payable tracking
- Payments
- Business expenses and owner withdrawal
- Monthly profit/loss report
- Backup and CSV export

## Technology
- Backend: Node.js + Express + SQLite
- Frontend: React + Vite
- Data persistence: `server/data/alhera.db`
- Backup folder: `server/backups`

## Run locally

### 1) Install dependencies
```bash
npm run install:all
```

### 2) Start backend API
```bash
npm --prefix server run dev
```

API will run on:
```text
http://localhost:5050
```

### 3) Start frontend
Open another terminal:
```bash
npm --prefix client run dev
```

Frontend will run on:
```text
http://localhost:5173
```

## Important data safety notes
- Do not delete `server/data/alhera.db`.
- Use the Backup button from the website regularly.
- Copy the `server/backups` folder to Google Drive/OneDrive every week.
- If you host online, use PostgreSQL/MySQL or a persistent disk.

## Default workflow
1. Add customer and supplier.
2. Add product type and estimated prices.
3. Create one sales order.
4. Select supplier inside that same order.
5. When factory gives actual kg, update actual quantity.
6. Record customer payment and supplier payment.
7. Check dashboard/report.

## Status meaning
- Waiting: order received, not completed yet.
- Supplier Ordered: supplier/factory order placed.
- Production: supplier is making product.
- Pickup: product ready / picked from factory.
- Delivery: delivered to customer, bill active.
- Completed: work and payment are closed.
- Cancelled: order cancelled.
