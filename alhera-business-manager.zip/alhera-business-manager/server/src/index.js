\
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import fs from "fs";
import { db, initDb, uid, nowIso, audit, makeOrderNo, orderTotals, createBackup, backupsPath } from "./db.js";

const app = express();
const PORT = Number(process.env.PORT || 5050);

initDb();

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(morgan("dev"));

function ok(res, data) {
  res.json({ ok: true, data });
}

function fail(res, error, code = 400) {
  res.status(code).json({ ok: false, error: String(error?.message || error) });
}

function parseNumber(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function rowsWithTotals(rows) {
  return rows.map((o) => ({ ...o, totals: orderTotals(o) }));
}

app.get("/api/health", (req, res) => ok(res, { status: "running", time: nowIso() }));

// ---------- Customers ----------
app.get("/api/customers", (req, res) => {
  ok(res, db.prepare("SELECT * FROM customers ORDER BY created_at DESC").all());
});

app.post("/api/customers", (req, res) => {
  try {
    const t = nowIso();
    const id = uid("cus");
    const { name, phone = "", address = "", opening_balance_receivable = 0, note = "" } = req.body;
    if (!name) throw new Error("Customer name is required");
    db.prepare(`
      INSERT INTO customers (id, name, phone, address, opening_balance_receivable, note, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, name, phone, address, parseNumber(opening_balance_receivable), note, t, t);
    audit("create", "customer", id, req.body);
    ok(res, db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
  } catch (e) { fail(res, e); }
});

app.put("/api/customers/:id", (req, res) => {
  try {
    const { name, phone = "", address = "", opening_balance_receivable = 0, note = "" } = req.body;
    db.prepare(`
      UPDATE customers
      SET name=?, phone=?, address=?, opening_balance_receivable=?, note=?, updated_at=?
      WHERE id=?
    `).run(name, phone, address, parseNumber(opening_balance_receivable), note, nowIso(), req.params.id);
    audit("update", "customer", req.params.id, req.body);
    ok(res, db.prepare("SELECT * FROM customers WHERE id = ?").get(req.params.id));
  } catch (e) { fail(res, e); }
});

// ---------- Suppliers ----------
app.get("/api/suppliers", (req, res) => {
  ok(res, db.prepare("SELECT * FROM suppliers ORDER BY created_at DESC").all());
});

app.post("/api/suppliers", (req, res) => {
  try {
    const t = nowIso();
    const id = uid("sup");
    const { name, phone = "", address = "", opening_balance_payable = 0, note = "" } = req.body;
    if (!name) throw new Error("Supplier name is required");
    db.prepare(`
      INSERT INTO suppliers (id, name, phone, address, opening_balance_payable, note, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, name, phone, address, parseNumber(opening_balance_payable), note, t, t);
    audit("create", "supplier", id, req.body);
    ok(res, db.prepare("SELECT * FROM suppliers WHERE id = ?").get(id));
  } catch (e) { fail(res, e); }
});

app.put("/api/suppliers/:id", (req, res) => {
  try {
    const { name, phone = "", address = "", opening_balance_payable = 0, note = "" } = req.body;
    db.prepare(`
      UPDATE suppliers
      SET name=?, phone=?, address=?, opening_balance_payable=?, note=?, updated_at=?
      WHERE id=?
    `).run(name, phone, address, parseNumber(opening_balance_payable), note, nowIso(), req.params.id);
    audit("update", "supplier", req.params.id, req.body);
    ok(res, db.prepare("SELECT * FROM suppliers WHERE id = ?").get(req.params.id));
  } catch (e) { fail(res, e); }
});

// ---------- Product Types ----------
app.get("/api/product-types", (req, res) => {
  const rows = db.prepare(`
    SELECT pt.*, s.name AS supplier_name
    FROM product_types pt
    LEFT JOIN suppliers s ON s.id = pt.supplier_id
    WHERE pt.active = 1
    ORDER BY pt.updated_at DESC
  `).all();
  ok(res, rows);
});

app.post("/api/product-types", (req, res) => {
  try {
    const t = nowIso();
    const id = uid("ptype");
    const {
      name, layer = "", material_combo = "", supplier_id = null,
      unit = "kg", estimated_purchase_price = 0, estimated_sale_price = 0, note = ""
    } = req.body;
    if (!name) throw new Error("Product type name is required");
    db.prepare(`
      INSERT INTO product_types
      (id, name, layer, material_combo, supplier_id, unit, estimated_purchase_price, estimated_sale_price, note, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id, name, layer, material_combo, supplier_id || null, unit,
      parseNumber(estimated_purchase_price), parseNumber(estimated_sale_price), note, t, t
    );
    audit("create", "product_type", id, req.body);
    ok(res, db.prepare("SELECT * FROM product_types WHERE id=?").get(id));
  } catch (e) { fail(res, e); }
});

app.put("/api/product-types/:id", (req, res) => {
  try {
    const {
      name, layer = "", material_combo = "", supplier_id = null,
      unit = "kg", estimated_purchase_price = 0, estimated_sale_price = 0, note = ""
    } = req.body;
    db.prepare(`
      UPDATE product_types
      SET name=?, layer=?, material_combo=?, supplier_id=?, unit=?, estimated_purchase_price=?,
          estimated_sale_price=?, note=?, updated_at=?
      WHERE id=?
    `).run(
      name, layer, material_combo, supplier_id || null, unit,
      parseNumber(estimated_purchase_price), parseNumber(estimated_sale_price), note, nowIso(), req.params.id
    );
    audit("update", "product_type", req.params.id, req.body);
    ok(res, db.prepare("SELECT * FROM product_types WHERE id=?").get(req.params.id));
  } catch (e) { fail(res, e); }
});

// ---------- Orders ----------
app.get("/api/orders", (req, res) => {
  const rows = db.prepare(`
    SELECT o.*, c.name AS customer_name, s.name AS supplier_name, pt.name AS saved_product_type
    FROM orders o
    JOIN customers c ON c.id = o.customer_id
    LEFT JOIN suppliers s ON s.id = o.supplier_id
    LEFT JOIN product_types pt ON pt.id = o.product_type_id
    ORDER BY o.created_at DESC
  `).all();
  ok(res, rowsWithTotals(rows));
});

app.post("/api/orders", (req, res) => {
  try {
    const t = nowIso();
    const id = uid("ord");
    const productType = req.body.product_type_id
      ? db.prepare("SELECT * FROM product_types WHERE id=?").get(req.body.product_type_id)
      : null;

    const customer_id = req.body.customer_id;
    if (!customer_id) throw new Error("Customer is required");
    const product_name = req.body.product_name;
    if (!product_name) throw new Error("Product name is required in sales order");

    const supplier_id = req.body.supplier_id || productType?.supplier_id || null;
    const unit = req.body.unit || productType?.unit || "kg";
    const purchase_rate = req.body.purchase_rate !== undefined ? req.body.purchase_rate : productType?.estimated_purchase_price || 0;
    const sale_rate = req.body.sale_rate !== undefined ? req.body.sale_rate : productType?.estimated_sale_price || 0;

    db.prepare(`
      INSERT INTO orders
      (id, order_no, customer_id, supplier_id, product_type_id, product_name, product_type_name, unit,
       estimated_qty, actual_qty, purchase_rate, sale_rate, transport_cost, extra_cost, status,
       order_date, expected_date, note, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      makeOrderNo(),
      customer_id,
      supplier_id,
      req.body.product_type_id || null,
      product_name,
      productType?.name || req.body.product_type_name || "",
      unit,
      parseNumber(req.body.estimated_qty),
      parseNumber(req.body.actual_qty),
      parseNumber(purchase_rate),
      parseNumber(sale_rate),
      parseNumber(req.body.transport_cost),
      parseNumber(req.body.extra_cost),
      req.body.status || "waiting",
      req.body.order_date || new Date().toISOString().slice(0, 10),
      req.body.expected_date || "",
      req.body.note || "",
      t,
      t
    );
    audit("create", "order", id, req.body);
    const row = db.prepare(`
      SELECT o.*, c.name AS customer_name, s.name AS supplier_name
      FROM orders o
      JOIN customers c ON c.id=o.customer_id
      LEFT JOIN suppliers s ON s.id=o.supplier_id
      WHERE o.id=?
    `).get(id);
    ok(res, { ...row, totals: orderTotals(row) });
  } catch (e) { fail(res, e); }
});

app.put("/api/orders/:id", (req, res) => {
  try {
    const current = db.prepare("SELECT * FROM orders WHERE id=?").get(req.params.id);
    if (!current) throw new Error("Order not found");

    const merged = { ...current, ...req.body };
    db.prepare(`
      UPDATE orders SET
        customer_id=?, supplier_id=?, product_type_id=?, product_name=?, product_type_name=?, unit=?,
        estimated_qty=?, actual_qty=?, purchase_rate=?, sale_rate=?, transport_cost=?, extra_cost=?,
        status=?, order_date=?, expected_date=?, completed_date=?, note=?, updated_at=?
      WHERE id=?
    `).run(
      merged.customer_id,
      merged.supplier_id || null,
      merged.product_type_id || null,
      merged.product_name,
      merged.product_type_name || "",
      merged.unit || "kg",
      parseNumber(merged.estimated_qty),
      parseNumber(merged.actual_qty),
      parseNumber(merged.purchase_rate),
      parseNumber(merged.sale_rate),
      parseNumber(merged.transport_cost),
      parseNumber(merged.extra_cost),
      merged.status || "waiting",
      merged.order_date,
      merged.expected_date || "",
      merged.completed_date || (merged.status === "completed" ? new Date().toISOString().slice(0, 10) : ""),
      merged.note || "",
      nowIso(),
      req.params.id
    );
    audit("update", "order", req.params.id, req.body);
    const row = db.prepare(`
      SELECT o.*, c.name AS customer_name, s.name AS supplier_name
      FROM orders o
      JOIN customers c ON c.id=o.customer_id
      LEFT JOIN suppliers s ON s.id=o.supplier_id
      WHERE o.id=?
    `).get(req.params.id);
    ok(res, { ...row, totals: orderTotals(row) });
  } catch (e) { fail(res, e); }
});

app.patch("/api/orders/:id/status", (req, res) => {
  try {
    const status = req.body.status;
    const completed_date = status === "completed" ? new Date().toISOString().slice(0, 10) : "";
    db.prepare("UPDATE orders SET status=?, completed_date=?, updated_at=? WHERE id=?")
      .run(status, completed_date, nowIso(), req.params.id);
    audit("status", "order", req.params.id, req.body);
    ok(res, db.prepare("SELECT * FROM orders WHERE id=?").get(req.params.id));
  } catch (e) { fail(res, e); }
});

// ---------- Payments ----------
app.get("/api/payments", (req, res) => {
  const rows = db.prepare(`
    SELECT p.*,
      CASE WHEN p.party_type='customer' THEN c.name ELSE s.name END AS party_name,
      o.order_no
    FROM payments p
    LEFT JOIN customers c ON c.id=p.party_id AND p.party_type='customer'
    LEFT JOIN suppliers s ON s.id=p.party_id AND p.party_type='supplier'
    LEFT JOIN orders o ON o.id=p.order_id
    ORDER BY p.payment_date DESC, p.created_at DESC
  `).all();
  ok(res, rows);
});

app.post("/api/payments", (req, res) => {
  try {
    const t = nowIso();
    const id = uid("pay");
    const { party_type, party_id, order_id = null, direction, amount, method = "cash", payment_date, note = "" } = req.body;
    if (!party_type || !party_id || !direction || !amount) throw new Error("Party, direction and amount are required");
    db.prepare(`
      INSERT INTO payments
      (id, party_type, party_id, order_id, direction, amount, method, payment_date, note, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, party_type, party_id, order_id || null, direction, parseNumber(amount), method, payment_date || new Date().toISOString().slice(0, 10), note, t, t);
    audit("create", "payment", id, req.body);
    ok(res, db.prepare("SELECT * FROM payments WHERE id=?").get(id));
  } catch (e) { fail(res, e); }
});

// ---------- Expenses ----------
app.get("/api/expenses", (req, res) => {
  ok(res, db.prepare("SELECT * FROM expenses ORDER BY expense_date DESC, created_at DESC").all());
});

app.post("/api/expenses", (req, res) => {
  try {
    const t = nowIso();
    const id = uid("exp");
    const { type = "business_expense", amount, method = "cash", expense_date, note = "" } = req.body;
    if (!amount) throw new Error("Amount is required");
    db.prepare(`
      INSERT INTO expenses (id, type, amount, method, expense_date, note, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, type, parseNumber(amount), method, expense_date || new Date().toISOString().slice(0, 10), note, t, t);
    audit("create", "expense", id, req.body);
    ok(res, db.prepare("SELECT * FROM expenses WHERE id=?").get(id));
  } catch (e) { fail(res, e); }
});

// ---------- Reports ----------
function computeSummary(where = "", params = []) {
  const orders = db.prepare(`
    SELECT * FROM orders
    WHERE status != 'cancelled' ${where}
  `).all(...params);

  let sales = 0, purchase = 0, transport = 0, extra = 0;
  for (const o of orders) {
    const t = orderTotals(o);
    sales += t.sale;
    purchase += t.purchase;
    transport += t.transport;
    extra += t.extra;
  }

  const expenseWhere = where.includes("order_date") ? where.replaceAll("order_date", "expense_date") : "";
  const businessExpenses = db.prepare(`
    SELECT COALESCE(SUM(amount), 0) AS total FROM expenses
    WHERE type='business_expense' ${expenseWhere}
  `).get(...params).total;

  const ownerWithdrawals = db.prepare(`
    SELECT COALESCE(SUM(amount), 0) AS total FROM expenses
    WHERE type='owner_withdrawal' ${expenseWhere}
  `).get(...params).total;

  const customerOpening = db.prepare("SELECT COALESCE(SUM(opening_balance_receivable), 0) AS total FROM customers").get().total;
  const supplierOpening = db.prepare("SELECT COALESCE(SUM(opening_balance_payable), 0) AS total FROM suppliers").get().total;
  const customerPaid = db.prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE party_type='customer' AND direction='in'").get().total;
  const supplierPaid = db.prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE party_type='supplier' AND direction='out'").get().total;

  const grossProfit = sales - purchase - transport - extra;
  const netProfit = grossProfit - businessExpenses;

  return {
    sales, purchase, transport, extra,
    grossProfit, businessExpenses, ownerWithdrawals,
    netProfit,
    cashAfterOwnerWithdrawal: netProfit - ownerWithdrawals,
    receivable: customerOpening + sales - customerPaid,
    payable: supplierOpening + purchase - supplierPaid,
    orders: orders.length
  };
}

app.get("/api/dashboard", (req, res) => {
  ok(res, computeSummary());
});

app.get("/api/reports/monthly", (req, res) => {
  const month = req.query.month || new Date().toISOString().slice(0, 7);
  const start = `${month}-01`;
  const end = new Date(new Date(start).getFullYear(), new Date(start).getMonth() + 1, 1).toISOString().slice(0, 10);
  ok(res, { month, ...computeSummary("AND order_date >= ? AND order_date < ?", [start, end]) });
});

app.get("/api/reports/customer/:id", (req, res) => {
  const c = db.prepare("SELECT * FROM customers WHERE id=?").get(req.params.id);
  if (!c) return fail(res, "Customer not found", 404);
  const orders = rowsWithTotals(db.prepare("SELECT * FROM orders WHERE customer_id=? ORDER BY order_date DESC").all(req.params.id));
  const payments = db.prepare("SELECT * FROM payments WHERE party_type='customer' AND party_id=? ORDER BY payment_date DESC").all(req.params.id);
  const orderTotal = orders.filter(o => o.status !== "cancelled").reduce((sum, o) => sum + o.totals.sale, 0);
  const paid = payments.filter(p => p.direction === "in").reduce((sum, p) => sum + Number(p.amount || 0), 0);
  ok(res, { customer: c, orders, payments, receivable: Number(c.opening_balance_receivable || 0) + orderTotal - paid });
});

app.get("/api/reports/supplier/:id", (req, res) => {
  const s = db.prepare("SELECT * FROM suppliers WHERE id=?").get(req.params.id);
  if (!s) return fail(res, "Supplier not found", 404);
  const orders = rowsWithTotals(db.prepare("SELECT * FROM orders WHERE supplier_id=? ORDER BY order_date DESC").all(req.params.id));
  const payments = db.prepare("SELECT * FROM payments WHERE party_type='supplier' AND party_id=? ORDER BY payment_date DESC").all(req.params.id);
  const orderTotal = orders.filter(o => o.status !== "cancelled").reduce((sum, o) => sum + o.totals.purchase, 0);
  const paid = payments.filter(p => p.direction === "out").reduce((sum, p) => sum + Number(p.amount || 0), 0);
  ok(res, { supplier: s, orders, payments, payable: Number(s.opening_balance_payable || 0) + orderTotal - paid });
});

// ---------- Export & backup ----------
function toCsv(rows) {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const esc = (v) => `"${String(v ?? "").replaceAll('"', '""')}"`;
  return [headers.join(","), ...rows.map(r => headers.map(h => esc(r[h])).join(","))].join("\n");
}

app.get("/api/export/:name.csv", (req, res) => {
  const allowed = new Set(["customers", "suppliers", "product_types", "orders", "payments", "expenses"]);
  const name = req.params.name;
  if (!allowed.has(name)) return fail(res, "Export not allowed", 404);
  const rows = db.prepare(`SELECT * FROM ${name}`).all();
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${name}.csv"`);
  res.send("\ufeff" + toCsv(rows));
});

app.post("/api/backup", (req, res) => {
  try {
    ok(res, createBackup());
  } catch (e) { fail(res, e, 500); }
});

app.get("/api/backups", (req, res) => {
  const files = fs.readdirSync(backupsPath).sort().reverse();
  ok(res, files);
});

setInterval(() => {
  try { createBackup(); } catch (e) { console.error("Auto backup failed", e); }
}, 1000 * 60 * 60 * 24);

app.use((req, res) => fail(res, "Route not found", 404));

app.listen(PORT, () => {
  console.log(`Al-Hera API running at http://localhost:${PORT}`);
});
