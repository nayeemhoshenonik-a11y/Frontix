\
import Database from "better-sqlite3";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const serverRoot = path.resolve(__dirname, "..");
const dataDir = path.join(serverRoot, "data");
const backupDir = path.join(serverRoot, "backups");

fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(backupDir, { recursive: true });

export const dbPath = path.join(dataDir, "alhera.db");
export const backupsPath = backupDir;

export const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

export function uid(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export function nowIso() {
  return new Date().toISOString();
}

export function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      opening_balance_receivable REAL DEFAULT 0,
      note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      opening_balance_payable REAL DEFAULT 0,
      note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS product_types (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      layer TEXT,
      material_combo TEXT,
      supplier_id TEXT,
      unit TEXT DEFAULT 'kg',
      estimated_purchase_price REAL DEFAULT 0,
      estimated_sale_price REAL DEFAULT 0,
      note TEXT,
      active INTEGER DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      order_no TEXT UNIQUE NOT NULL,
      customer_id TEXT NOT NULL,
      supplier_id TEXT,
      product_type_id TEXT,
      product_name TEXT NOT NULL,
      product_type_name TEXT,
      unit TEXT DEFAULT 'kg',
      estimated_qty REAL DEFAULT 0,
      actual_qty REAL DEFAULT 0,
      purchase_rate REAL DEFAULT 0,
      sale_rate REAL DEFAULT 0,
      transport_cost REAL DEFAULT 0,
      extra_cost REAL DEFAULT 0,
      status TEXT DEFAULT 'waiting',
      order_date TEXT NOT NULL,
      expected_date TEXT,
      completed_date TEXT,
      note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT,
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
      FOREIGN KEY (product_type_id) REFERENCES product_types(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      party_type TEXT NOT NULL,
      party_id TEXT NOT NULL,
      order_id TEXT,
      direction TEXT NOT NULL,
      amount REAL NOT NULL,
      method TEXT DEFAULT 'cash',
      payment_date TEXT NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      method TEXT DEFAULT 'cash',
      expense_date TEXT NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      action TEXT NOT NULL,
      entity TEXT NOT NULL,
      entity_id TEXT,
      details TEXT,
      created_at TEXT NOT NULL
    );
  `);

  const count = db.prepare("SELECT COUNT(*) AS c FROM product_types").get().c;
  if (count === 0) seedProductTypes();
}

export function audit(action, entity, entity_id, details = {}) {
  db.prepare(`
    INSERT INTO audit_logs (id, action, entity, entity_id, details, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(uid("log"), action, entity, entity_id, JSON.stringify(details), nowIso());
}

function seedProductTypes() {
  const items = [
    ["1 Layer Printed Poly", "1 Layer", "LDPE / PP / HDPE", "kg", 0, 0],
    ["2 Layer PET + LDPE", "2 Layer", "PET + LDPE", "kg", 0, 0],
    ["2 Layer BOPP + LDPE", "2 Layer", "BOPP + LDPE", "kg", 0, 0],
    ["3 Layer PET + Foil + LDPE", "3 Layer", "PET + Foil + LDPE", "kg", 0, 0],
    ["3 Layer PET + Metalized PET + LDPE", "3 Layer", "PET + Metalized PET + LDPE", "kg", 0, 0],
    ["4 Layer Premium Pack", "4 Layer", "PET + Foil + Nylon + LDPE", "kg", 0, 0],
    ["Cylinder", "Cylinder", "Digital / Manual Cylinder", "pcs", 0, 0],
    ["Block Printing", "Block", "Block print item", "pcs", 0, 0]
  ];

  const stmt = db.prepare(`
    INSERT INTO product_types
    (id, name, layer, material_combo, unit, estimated_purchase_price, estimated_sale_price, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const t = nowIso();
  for (const row of items) {
    stmt.run(uid("ptype"), row[0], row[1], row[2], row[3], row[4], row[5], t, t);
  }
}

export function list(table) {
  return db.prepare(`SELECT * FROM ${table} ORDER BY created_at DESC`).all();
}

export function getById(table, id) {
  return db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
}

export function makeOrderNo() {
  const d = new Date();
  const ymd = d.toISOString().slice(0, 10).replaceAll("-", "");
  const row = db.prepare("SELECT COUNT(*) AS c FROM orders WHERE order_no LIKE ?").get(`AH-${ymd}-%`);
  return `AH-${ymd}-${String(row.c + 1).padStart(4, "0")}`;
}

export function orderTotals(order) {
  const qty = Number(order.actual_qty || order.estimated_qty || 0);
  const purchase = qty * Number(order.purchase_rate || 0);
  const sale = qty * Number(order.sale_rate || 0);
  const transport = Number(order.transport_cost || 0);
  const extra = Number(order.extra_cost || 0);
  const grossProfit = sale - purchase - transport - extra;
  return { qty, purchase, sale, transport, extra, grossProfit };
}

export function createBackup() {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const dbBackup = path.join(backupDir, `alhera-db-${stamp}.db`);
  const jsonBackup = path.join(backupDir, `alhera-data-${stamp}.json`);

  db.exec("PRAGMA wal_checkpoint(FULL)");
  fs.copyFileSync(dbPath, dbBackup);

  const payload = {};
  for (const table of ["customers", "suppliers", "product_types", "orders", "payments", "expenses", "audit_logs"]) {
    payload[table] = db.prepare(`SELECT * FROM ${table}`).all();
  }
  fs.writeFileSync(jsonBackup, JSON.stringify(payload, null, 2), "utf-8");

  return { dbBackup, jsonBackup };
}
